package lk.ijse.Controller;

import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.Model.UserModel;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

public class LoginFormController {
    public AnchorPane root;
    public JFXButton btnLogin;


    @FXML
    private TextField txtusername;


    @FXML
    private Label lbltime;

    @FXML
    private PasswordField btnpassword;
    private UserModel userModel = new UserModel();

    public void initialize() {
        setDate();
    }

    private void setDate() {
        lbltime.setText(String.valueOf(LocalDate.now()));
    }

    @FXML
    void btnLoginOnAction(ActionEvent event) throws IOException {
        if (!txtusername.getText().equals("")) {
            try {
                if (userModel.searchUser(txtusername.getText(), btnpassword.getText())) {
                    Stage stage = (Stage) this.root.getScene().getWindow();
                    stage.setScene(new Scene(FXMLLoader.load(this.getClass().getResource("/View/dashboard_form.fxml"))));
                    stage.show();
                }
            } catch (SQLException e) {
                new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
            }
        } else {
            new Alert(Alert.AlertType.ERROR, "Fields are empty!1").show();
        }

    }
}
