package lk.ijse.Model;

import javafx.scene.control.Alert;
import lk.ijse.DB.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserModel {

    public boolean searchUser(String username, String password) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        PreparedStatement pstm = connection.prepareStatement("select * from user Where user_id = ?");
        pstm.setString(1, username);

        ResultSet resultSet = pstm.executeQuery();

        if (resultSet.next()) {

            if (password.equals(resultSet.getString(3))) {
                return true;
            }
        }
        return false;
    }
}
