package lk.ijse.dto.tm;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class EmployeeTm {
 private String id;
 private String name;
 private String address;
 private String tel;

}
